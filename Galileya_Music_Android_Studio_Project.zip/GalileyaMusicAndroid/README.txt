GALILEYA MUSIC — ANDROID STUDIO PROJECT
======================================

This package contains the first Android wrapper project around the Galileya Music web player.

IMPORTANT: This is the Android source project, NOT a prebuilt APK. The build environment here does not include the Android SDK, so a signed/installed APK could not be compiled directly.

BUILD FOR FREE
--------------
1. Download and install Android Studio on a computer (Windows, macOS, or Linux).
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted GalileyaMusicAndroid folder.
4. Allow Gradle sync and install any Android SDK platform/build tools it requests.
5. Connect an Android phone with USB debugging enabled, or use an emulator.
6. Press Run to test, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show the location of the generated APK.

APP FEATURES
------------
- Local audio file picker (choose music on the device)
- Search, play/pause, previous/next
- Favourites
- Basic playlist creation
- Browser database storage for imported audio, subject to WebView/device support
- Galileya Music branding and dark UI

NOTES
-----
- Use audio files you own or have permission to use.
- Keep the project folder intact so Android Studio can find all Gradle files.
- For a release APK, create a signed build in Android Studio. Do not share your signing key.
- This is an early prototype; test file import and offline playback on your own phone before relying on it.
